To whom it may concern,

CS149 Project 2 was completed as a coordinated and collaborative effort by the following 6 people:
Stephen Reyes
Hansen Wu
Kito Mam
Ivana Yu
David Xie
Yoho Chen

The project was divided into 3 parts:

1. Java/GUI (part 2), by Ivana and David
2. Linking C++/DLL to Java using JNI (part 2), by Stephen and Yoho
3. C++ shell and data handling (part 1), by Hansen and Kito

For six people, this took two days. This would have taken 12 days or more as an individually completed project. 
We decided to team up and work on distributed parts simultaneously, as to get the work done on time.

This note has been included in the assignment submission's comments, as well as the README plaintext in the submitted zip file.

- SJSU CS 149-4 Team, Spring 2016