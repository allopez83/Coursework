import java.io.File;

/**
 * 
 */
public class FileIO
{

   /**
     * 
     */
   public FileIO()
   {
   }

   /**
     * 
     */
   private File file;

   /**
     * 
     */
   void loadCalendar()
   {
      // TODO implement here
   }

   /**
    * @param cal
    */
   void saveCalendar(MyCalendar cal)
   {
      // TODO implement here
   }

}