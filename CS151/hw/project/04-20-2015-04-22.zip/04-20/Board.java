
public interface Board  {
	
	public void drawParts();
	
}
