import java.awt.event.MouseListener;


public interface Board {
	public void drawParts();
	public void addPitListener(MouseListener l) ;
}
