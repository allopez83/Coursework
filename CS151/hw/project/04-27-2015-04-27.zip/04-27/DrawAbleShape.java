import java.awt.Graphics2D;


public interface DrawAbleShape {
	void draw (Graphics2D g2);
}
