

/**
 * Mancala Project
 * 
 * CS151 Spring 2015 
 * Team: Infinite Loop
 * 
 * @author Jordan Petersen,(Ryan) Tuan Phan, Dustin Tran, Hansen Wu
 * @version 05/09/15
 */
public class Mancala {

    public static void main(String[] args) 
    {
        Controller mancalaController = new Controller();
        
    }
    
}
