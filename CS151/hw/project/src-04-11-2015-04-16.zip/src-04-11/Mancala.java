
public class Mancala {

    public static void main(String[] args) 
    {
        Controller mancalaController = new Controller();
        
    }
    
}
