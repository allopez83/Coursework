public interface Cipher
{
   int shift = 3;
   String cipher(String s);
}
