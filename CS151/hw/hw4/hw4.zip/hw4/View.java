import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

/**
 * All GUI and visual related aspects of SimpleCalendar
 * @author Hansen Wu
 *
 */
public class View extends JFrame
{
    private final int DAY_IN_WEEK = 7, WEEK_IN_MONTH = 6, DAY_HOURS = 24;
    private final Border blackBorder = BorderFactory.createLineBorder(Color.BLACK);
    private JPanel left, right, top;
    private JPanel day, dayTime, dayEvents;
    private JPanel month;
    private JButton next, prev, create, quit;
    private JLabel monthLabel, dayLabel;

    private GregorianCalendar currentDay;
    private Events events;
    private ActionListener monthAction;
    private ActionListener saveAction;
    private DayViewComponent dvc;

    /**
     * Creates the primary window
     */
    public View()
    {
        create = new JButton("Create Event");
        prev = new JButton("<- Prev");
        next = new JButton("Next ->");
        quit = new JButton("Quit");

        monthLabel = new JLabel();
        dayLabel = new JLabel();
    }

    /**
     * Renders and displays the GUI of SimpleCalendar
     */
    public void display()
    {
        topPanel();
        leftPanel();
        rightPanel();

        top.setBorder(blackBorder);
        left.setBorder(blackBorder);
        right.setBorder(blackBorder);
        month.setBorder(blackBorder);
        day.setBorder(blackBorder);
        dayTime.setBorder(blackBorder);
        dayEvents.setBorder(blackBorder);
        day.setPreferredSize(new Dimension(300, 800));

        // Main
        this.setLayout(new BorderLayout());
        this.add(top, BorderLayout.NORTH);
        this.add(left, BorderLayout.WEST);
        this.add(right, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }

    /**
     * Creates top SimpleCalendar panel with buttons
     */
    private void topPanel()
    {
        top = new JPanel();

        top.add(create);
        top.add(prev);
        top.add(next);
        top.add(quit);
    }

    /**
     * Creates left SimpleCalendar panel with month view
     */
    private void leftPanel()
    {
        left = new JPanel(new BorderLayout());
        month = new JPanel(new GridBagLayout());

        left.add(monthLabel, BorderLayout.NORTH);
        left.add(month, BorderLayout.CENTER);

        drawMonth(); // Initially nothing
    }

    /**
     * Creates right SimpleCalendar panel with day view
     */
    private void rightPanel()
    {
        right = new JPanel(new BorderLayout());
        day = new JPanel(new BorderLayout());
        dayTime = new JPanel(new GridLayout(24 * 2, 2));
        dayEvents = new JPanel(new BorderLayout());

        right.add(dayLabel, BorderLayout.NORTH);
        right.add(day, BorderLayout.CENTER);

        day.add(dayTime, BorderLayout.WEST);
        day.add(dayEvents, BorderLayout.CENTER);

        dvc = new DayViewComponent(dayEvents, events);

        drawDayTime();
        drawDayEvents(events); // Draw the day
    }

    /**
     * Redraw the month and day view to reflect new day or view to look at
     * @param Integer
     */
    public void redraw()
    {
        drawDayEvents(events);
        drawMonth();
    }

    /**
     * Draw month, including day buttons and day of week labels
     */
    public void drawMonth()
    {
        // Prevent duplicate buttons
        month.removeAll();

        int days = 1;
        int countdown = getMonthDelay();
        int max = currentDay.getActualMaximum(Calendar.DATE);
        GridBagConstraints c = new GridBagConstraints();
        int today = currentDay.get(Calendar.DATE);

        String[] weekdayNames = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri",
                "Sat" };
        JLabel weekday;
        JButton dayButton;

        // Draw weekday labels
        for (int i = 0; i < DAY_IN_WEEK; i++) // week
        {
            weekday = new JLabel(weekdayNames[i]);
            weekday.setBorder(blackBorder);
            c.fill = GridBagConstraints.BOTH;
            c.gridx = i;
            c.gridy = 0;
            month.add(weekday, c);
        }

        // Draw on buttons
        for (int i = 0; i < WEEK_IN_MONTH && days < max + 1; i++) // week
        {
            for (int j = 0; j < DAY_IN_WEEK && days < max + 1; j++) // day
            {
                countdown--;
                if (days > countdown)
                {
                    dayButton = new JButton(days + "");
                    dayButton.addActionListener(monthAction);
                    if (days == today)
                        dayButton.setBorder(BorderFactory.createLineBorder(
                                Color.BLACK, 3));
                    days++;
                    c.fill = GridBagConstraints.BOTH;
                    c.ipady = 20;
                    c.gridx = j;
                    c.gridy = i + 1; // +1 because of weekday row
                    month.add(dayButton, c);
                }
            }
        }

        month.repaint();
        month.updateUI();
    }

    /**
     * Finds the number of days before the first day of the month, in order to
     * render days of the week correctly
     * @return
     */
    private Integer getMonthDelay()
    {
        GregorianCalendar gc = (GregorianCalendar) currentDay.clone();
        gc.set(Calendar.DATE, 1);
        return gc.get(Calendar.DAY_OF_WEEK);
    }

    /**
     * Draws timestamp on dayTime JPanel. Only needs to be done once.
     * @param events
     */
    public void drawDayTime()
    {
        // Draw time of day labels
        for (int i = 0; i < DAY_HOURS; i++) // Week
        {
            dayTime.add(new JLabel(i + ":00"));
            dayTime.add(new JLabel("")); // Extra space
        }
    }

    /**
     * Draws the events on the current day
     * @param events the Events object that contains data to be drawn
     */
    private void drawDayEvents(Events events)
    {
        // Remove current day events
        dayEvents.removeAll();
        dayEvents.repaint();

        if (events != null)
        {
            // Draw the new day
            dvc.setEvents(events);
            this.dayEvents.add(dvc);
        }
        else
        {
            // Draw simple background
        }
    }

    // ActionListeners
    public void addQuitListener(ActionListener l) { quit.addActionListener(l); }
    public void addPrevListener(ActionListener l) { prev.addActionListener(l); }
    public void addNextListener(ActionListener l) { next.addActionListener(l); }
    public void addCreateListener(ActionListener l) { create.addActionListener(l); }
    public void addSaveListener(ActionListener l) { saveAction = l; }
    public void addMonthViewListener(ActionListener l) { monthAction = l; }

    public void setMonthText(String m)
    {
        this.monthLabel.setText(m);
    }

    public void setDay(GregorianCalendar gc)
    {
        this.currentDay = gc;
    }

    public void setDayText(String d)
    {
        this.dayLabel.setText(d);
    }

    public void setEvents(Events events)
    {
        this.events = events;
    }

    public void repaint()
    {
        super.repaint();
    }

    public CreateView createMenu(String day)
    {
        CreateView cv = new CreateView(day);
        cv.addSaveListener(saveAction);
        return cv;
    }

}
