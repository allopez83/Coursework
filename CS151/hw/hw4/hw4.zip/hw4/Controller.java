import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * Initializes the SimpleCalendar program
 * @author Hansen Wu
 *
 */
public class Controller
{
    private View view;
    private Model model;

    public Controller()
    {
        model = new Model();
        view = new View();

        setUpButtons();

        model.setView(view);
        view.display();
    }

    /**
     * Gives buttons their listeners
     */
    private void setUpButtons()
    {
        view.addQuitListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                model.saveData();
                view.dispose();
            }
        });

        view.addPrevListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                model.prev();
            }
        });

        view.addNextListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                model.next();
            }
        });

        view.addCreateListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                model.createMenu();
            }
        });

        view.addSaveListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                model.saveEvent();
            }
        });

        view.addMonthViewListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {

                // Get day number
                JButton source = (JButton) e.getSource();
                int day = Integer.parseInt(source.getText());

                model.jumpToDay(day);
            }
        });
    }
}
