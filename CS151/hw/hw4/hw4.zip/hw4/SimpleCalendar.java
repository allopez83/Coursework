/**
 * Launches SimpleCalendar
 * @author Hansen Wu
 *
 */
public class SimpleCalendar
{

    public static void main(String[] args)
    {
        new Controller();
    }

}
