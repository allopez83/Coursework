Requirements
==============================
- min, max, avg price in each neighborhood
- Driver: complete code
- Mapper: partial code, implement TODOs
- Reducer: partial code, implement TODOs

Sample Output

```
Blmngtn 159895.0
Blmngtn 194870.88
Blmngtn 264561.0
Blueste 124000.0
Blueste 137500.0
Blueste 151000.0
BrDale  83000.0
BrDale  104493.75
BrDale  125000.0
BrkSide 39300.0
BrkSide 124834.055
BrkSide 223500.0
ClearCr 130000.0
ClearCr 212565.42
ClearCr 328000.0
CollgCr 110000.0
CollgCr 197965.77
CollgCr 424870.0
Crawfor 90350.0
Crawfor 210624.72
Crawfor 392500.0
Edwards 58500.0
Edwards 128219.7
```